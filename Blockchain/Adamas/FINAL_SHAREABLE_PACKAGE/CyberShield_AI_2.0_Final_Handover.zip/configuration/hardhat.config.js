require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
    solidity: {
        version: "0.8.24",
        settings: {
            optimizer: {
                enabled: true,
                runs: 200,
            },
        },
    },
    networks: {
        hardhat: {
            chainId: 31337,
        },
        // Uncomment when ready for testnet deployment:
        // sepolia: {
        //     url: process.env.SEPOLIA_RPC_URL || "",
        //     accounts: process.env.DEPLOYER_PRIVATE_KEY
        //         ? [process.env.DEPLOYER_PRIVATE_KEY]
        //         : [],
        //     chainId: 11155111,
        // },
    },
};

"""
CyberShield AI 2.0 — FastAPI Integration Snippets for Member 1
"""
import asyncio
from typing import Literal, Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from security.ssrf_validator import (
    SSRFValidator,
    PinnedSession,
    SSRFSecurityException,
    SSRFRedirectBlockedException,
)
from security.evidence_hasher import EvidenceHasher

app = FastAPI(title="CyberShield AI 2.0 API")

# Shared thread-safe DNS-pinned scanner session (trust_env=False enforced)
scanner_session = PinnedSession(max_redirects=3, timeout=5.0)


# ── Pydantic v2 Models ────────────────────────────────────────────────────────

class IntegrityBlock(BaseModel):
    status: Literal["verified", "failed", "not_available"]
    evidence_hash: Optional[str] = None


class ScanUrlRequest(BaseModel):
    url: str


class ScanUrlResponse(BaseModel):
    status_code: int
    resolved_ip: str
    connected_ip: str
    normalized_url: str
    headers: Dict[str, str]


class VerifyReportRequest(BaseModel):
    report_data: Dict[str, Any]
    expected_hash: str


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.post("/api/v1/scan-url", response_model=ScanUrlResponse)
async def scan_url(request: ScanUrlRequest):
    """
    Safely inspect an external URL with SSRF preflight protection,
    DNS pinning, and asyncio event-loop non-blocking dispatch.
    """
    val = SSRFValidator.validate_url(request.url, resolve_dns=True)
    if not val.is_safe:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "URL blocked by security preflight policy",
                "reason": val.blocked_reason,
                "violation_category": val.violation_category,
            }
        )

    try:
        # Offload synchronous socket I/O from asyncio loop
        response = await asyncio.to_thread(
            scanner_session.get,
            val.normalized_url,
            validation_result=val,
        )
    except SSRFRedirectBlockedException as e:
        raise HTTPException(status_code=400, detail={"error": "SSRF Redirect Blocked", "reason": str(e)})
    except SSRFSecurityException as e:
        raise HTTPException(status_code=400, detail={"error": "SSRF Security Violation", "reason": str(e)})
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Target connection failed: {e}")

    return {
        "status_code": response.status_code,
        "resolved_ip": val.resolved_ip,
        "connected_ip": response.pinned_ip,
        "normalized_url": val.normalized_url,
        "headers": dict(response.headers),
    }


@app.post("/api/v1/reports/verify")
async def verify_report(payload: VerifyReportRequest):
    """
    Verify the cryptographic integrity of a threat report.
    """
    result = EvidenceHasher.verify_integrity(
        report_data=payload.report_data,
        expected_hash=payload.expected_hash,
        algorithm="sha256"
    )
    return result.to_api_contract()


def finalize_threat_report(raw_report: dict) -> dict:
    """
    Injects the schema-compliant integrity block into a completed report dictionary.
    """
    evidence_hash = EvidenceHasher.hash_report(raw_report, algorithm="sha256")
    raw_report["integrity"] = {
        "status": "verified",
        "evidence_hash": evidence_hash
    }
    return raw_report

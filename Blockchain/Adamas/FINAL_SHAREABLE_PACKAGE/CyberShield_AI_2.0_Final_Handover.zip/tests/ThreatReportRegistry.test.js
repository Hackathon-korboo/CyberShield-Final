const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("ThreatReportRegistry — Full RBAC & Integration Test Suite", function () {

    let registry;
    let owner;
    let authorizedRegistrar;
    let unauthorizedAccount;
    let newOwner;

    beforeEach(async function () {
        [owner, authorizedRegistrar, unauthorizedAccount, newOwner] = await ethers.getSigners();

        const Registry = await ethers.getContractFactory("ThreatReportRegistry");
        registry = await Registry.deploy();
        await registry.waitForDeployment();

        // Authorize the registrar
        await registry.setRegistrar(authorizedRegistrar.address, true);
    });

    // ────────────────────────────────────────────────
    //  1. Access Control & Authorization Tests
    // ────────────────────────────────────────────────

    describe("Access Control (RBAC)", function () {
        it("Should allow the owner to register reports", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Report from Owner"));
            await expect(registry.connect(owner).registerReport(hash))
                .to.emit(registry, "ReportRegistered");
        });

        it("Should allow an authorized registrar to register reports", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Report from Authorized"));
            await expect(registry.connect(authorizedRegistrar).registerReport(hash))
                .to.emit(registry, "ReportRegistered");
        });

        it("Should revert when an unauthorized account attempts to register", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Report from Unauthorized"));
            await expect(registry.connect(unauthorizedAccount).registerReport(hash))
                .to.be.revertedWith("Caller is not authorized to register reports");
        });

        it("Should allow owner to authorize and revoke registrars", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Report Revoke Test"));

            // Revoke registrar
            await registry.setRegistrar(authorizedRegistrar.address, false);

            await expect(registry.connect(authorizedRegistrar).registerReport(hash))
                .to.be.revertedWith("Caller is not authorized to register reports");
        });

        it("Should handle ownership transfer and revoke previous owner registrar rights", async function () {
            // Transfer ownership to newOwner
            await registry.connect(owner).transferOwnership(newOwner.address);
            expect(await registry.owner()).to.equal(newOwner.address);

            // Previous owner should no longer be authorized
            const hashA = ethers.keccak256(ethers.toUtf8Bytes("Old Owner Test"));
            await expect(registry.connect(owner).registerReport(hashA))
                .to.be.revertedWith("Caller is not authorized to register reports");

            // New owner should be authorized
            const hashB = ethers.keccak256(ethers.toUtf8Bytes("New Owner Test"));
            await expect(registry.connect(newOwner).registerReport(hashB))
                .to.emit(registry, "ReportRegistered");
        });
    });

    // ────────────────────────────────────────────────
    //  2. Registration & State Readback Tests
    // ────────────────────────────────────────────────

    describe("registerReport & State Readback", function () {
        it("Should register a new report, verify receipt, and read back state", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Threat Report 001"));
            const reportId = await registry.generateReportId(hash);

            const tx = await registry.connect(owner).registerReport(hash);
            const receipt = await tx.wait();
            expect(receipt.status).to.equal(1);

            // Post-registration state readback
            const [retId, retHash, registrant, timestamp] = await registry.getReport(reportId);
            expect(retId).to.equal(reportId);
            expect(retHash).to.equal(hash);
            expect(registrant).to.equal(owner.address);
            expect(timestamp).to.be.gt(0);

            // Verify function
            expect(await registry.verifyReport(reportId, hash)).to.be.true;
        });

        it("Should increment reportCount after registration", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Threat Report Counter"));
            expect(await registry.reportCount()).to.equal(0);
            await registry.registerReport(hash);
            expect(await registry.reportCount()).to.equal(1);
        });

        it("Should reject a zero hash", async function () {
            await expect(
                registry.registerReport(ethers.ZeroHash)
            ).to.be.revertedWith("Invalid report hash");
        });

        it("Should reject duplicate report hashes", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Duplicate Report"));
            await registry.registerReport(hash);

            await expect(
                registry.registerReport(hash)
            ).to.be.revertedWith("Report already registered");
        });
    });

    // ────────────────────────────────────────────────
    //  3. Verification Tests
    // ────────────────────────────────────────────────

    describe("verifyReport", function () {
        it("Should verify the original report as true", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Verify Test"));
            const reportId = await registry.generateReportId(hash);
            await registry.registerReport(hash);

            expect(await registry.verifyReport(reportId, hash)).to.be.true;
        });

        it("Should reject a modified report hash", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Original Report"));
            const tamperedHash = ethers.keccak256(ethers.toUtf8Bytes("Tampered Report"));
            const reportId = await registry.generateReportId(hash);

            await registry.registerReport(hash);
            expect(await registry.verifyReport(reportId, tamperedHash)).to.be.false;
        });

        it("Should return false for an unregistered report", async function () {
            const hash = ethers.keccak256(ethers.toUtf8Bytes("Unregistered"));
            const reportId = await registry.generateReportId(hash);
            expect(await registry.verifyReport(reportId, hash)).to.be.false;
        });
    });
});

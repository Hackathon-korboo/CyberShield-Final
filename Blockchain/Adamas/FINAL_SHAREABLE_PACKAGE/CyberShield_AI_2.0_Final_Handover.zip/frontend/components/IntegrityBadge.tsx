import React from "react";
import { ReportIntegrity } from "./integrity";

interface Props {
  integrity: ReportIntegrity;
}

export const IntegrityBadge: React.FC<Props> = ({ integrity }) => {
  if (integrity.status === "verified") {
    return (
      <div className="flex items-center gap-2 px-3 py-1 bg-emerald-950/40 border border-emerald-500/50 rounded-full text-emerald-400 text-xs font-mono">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="font-semibold">Integrity Verified</span>
        {integrity.evidence_hash && (
          <span className="text-gray-400 text-[10px]">
            ({integrity.evidence_hash.substring(0, 8)}...)
          </span>
        )}
      </div>
    );
  }

  if (integrity.status === "failed") {
    return (
      <div className="flex items-center gap-2 px-3 py-1 bg-red-950/40 border border-red-500/50 rounded-full text-red-400 text-xs font-mono">
        <span className="w-2 h-2 rounded-full bg-red-500" />
        <span className="font-bold">Tamper Warning: Digest Mismatch!</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 px-3 py-1 bg-gray-900 border border-gray-700 rounded-full text-gray-400 text-xs font-mono">
      <span>Integrity Not Available</span>
    </div>
  );
};

/**
 * CyberShield AI 2.0 — Frontend Type Definitions
 */

export interface ReportIntegrity {
  status: "verified" | "failed" | "not_available";
  evidence_hash: string | null;
}

export interface ThreatReportResponse {
  report_id?: string;
  url: string;
  threat_level: "low" | "medium" | "high" | "critical";
  confidence: number;
  indicators: string[] | Array<{ ioc_type: string; value: string }>;
  integrity: ReportIntegrity;
  blockchain?: {
    is_on_chain: boolean;
    network: string;
    transaction_hash?: string;
    block_number?: number;
  };
}
